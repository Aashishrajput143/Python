s="python is a funny language"
i=s.rindex(" ")
s1=s[:i]
s2=s[i+1:]
print(s)
print(s1)
print(s2)
