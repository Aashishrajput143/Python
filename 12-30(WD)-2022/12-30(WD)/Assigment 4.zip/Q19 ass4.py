t=input('Enter the string:')
l=t.split()
print('\n'.join(sorted(l)))
