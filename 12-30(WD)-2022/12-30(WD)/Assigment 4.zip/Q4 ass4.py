t=input('Enter the 1st  string:')
s=input('Enter the 2nd string:')
t1=s[:2]+t[2:]
s1=t[:2]+s[2:]
print(t1+s1)
