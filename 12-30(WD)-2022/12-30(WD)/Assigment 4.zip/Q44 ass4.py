s="india is india"
s1=set(s)
s2="".join(s1)
print(s)
print(s2)
