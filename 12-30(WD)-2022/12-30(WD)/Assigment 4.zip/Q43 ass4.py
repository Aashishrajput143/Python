t=input('enter the string:  ')
print(t.title())
      
