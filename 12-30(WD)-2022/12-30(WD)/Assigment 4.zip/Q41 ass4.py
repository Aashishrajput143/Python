s=input('enter the string:')
p=s.count(' ')
l=s.split()
for i in range(p):
    print(' ',end='')
print(''.join(l))
      


