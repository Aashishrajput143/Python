s=input('Enter the string to find length:')
print('The length of the string is',len(s))
