t=input('Enter the string:')
r=t[0]
a=t[1:]
s=a.replace(r,'$')
print(r+s)
