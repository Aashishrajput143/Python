
t=input('Enter the comma separated sequence of words:')
a=t.split(',')
b=sorted(a)
print(','.join(b))
