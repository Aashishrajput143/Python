t=input('Enter the string:')
s=t.split()
l=t[-1::-1]
print(' '.join(l))
