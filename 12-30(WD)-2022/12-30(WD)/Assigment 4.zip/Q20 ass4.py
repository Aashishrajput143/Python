t='''India is my country.
Dhoni is the captain.
Delhi is the capital of india.'''
print(t)
t=t.replace('\n',' ')
print(t)
