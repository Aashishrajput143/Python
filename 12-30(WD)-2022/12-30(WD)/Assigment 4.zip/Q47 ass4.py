t=input('enter the string:')
print(t[-1::-1])
