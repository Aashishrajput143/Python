s=input('enter string ')
print(s.isalpha())
