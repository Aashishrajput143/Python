t=input('Enter the string:')
a=t[-2:]
print(4*a)
