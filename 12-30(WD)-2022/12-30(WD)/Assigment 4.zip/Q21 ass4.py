t=input('Enter the string:')
s=input('Enter the character which you want to check:')
if(t.startswith(s)):
    print('Yes')
else:
    print('No')
