t=input('Enter the string:')
if(t.endswith('ing')):
    print(t+'ly')
else:
    print(t+'ing')
