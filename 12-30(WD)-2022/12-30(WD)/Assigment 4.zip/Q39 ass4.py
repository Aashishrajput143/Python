s=input('enter the string:  ')
b=set(s)
l=list(b)
q=[]
for i in l:
    c=s.count(i)
    q.append(c)
r=sorted(q)
j=r[-2]
d=q.index(j)
print('second most repeated element:',l[d])
