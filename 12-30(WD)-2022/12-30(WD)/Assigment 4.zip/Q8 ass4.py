n=input('Enter the string:')
l=len(n)
a=s[:1]
b=s[l-1:]
c=s[1:l-1]
print(b+c+a)
