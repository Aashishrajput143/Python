s=input('enter string :')
v='aeiouAEIOU'
a=[]
for l in s:
    if(l in v):
        a.append(l)
print('lenght of the vowels:',len(a))
print('vowels are:',a)
