t=input('Enter the string:')
a=t[0:3]
print(a)
