s=input('enter the string:')
if(s==s[-1::-1]):
    print('yes it is palindrome')
else:
    print('it is not palindrome')
