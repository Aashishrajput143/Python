from itertools import permutations 
a=list(permutations(input('Enter a word : ')))
l=[]
for i in a:
    b=''.join(i)
    l.append(b)
print(len(l))
