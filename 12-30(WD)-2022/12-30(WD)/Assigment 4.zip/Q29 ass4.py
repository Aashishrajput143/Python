s=input('enter the string:  ')
l=s.split()
print(l)
