t=input('Enter the string:')
s=input('specify word u want to count:')
print(t.count(s))
