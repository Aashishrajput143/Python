t=input('Enter the string:')
t=t[0::2]
print(t)
