t=input('Enter the string:')
print('upper case',t.upper())
print('lower case',t.lower())
