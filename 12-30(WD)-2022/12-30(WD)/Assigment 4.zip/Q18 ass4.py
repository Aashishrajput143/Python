t=input('Enter the string:')
l=len(t)
a=t[:4]
b=0
for i in a:
    if(i.upper()):
        b=b+1
        if(b==2):
            print(t.upper())
    else:
        print(t)
