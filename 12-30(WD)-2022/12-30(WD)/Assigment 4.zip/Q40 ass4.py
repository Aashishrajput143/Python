t=input('enter the string:  ')
print(t.replace(' ',''))
      


