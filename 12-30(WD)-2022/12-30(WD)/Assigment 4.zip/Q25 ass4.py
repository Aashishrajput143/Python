t=input('Enter the string:')
a=input('Enter the character u want to strip:')
if a in t:
    print(t.strip(a))
else:
    print(t)
