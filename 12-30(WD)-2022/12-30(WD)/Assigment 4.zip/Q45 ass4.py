s=input('enter string ')
if('a' in s):
    print('yes a is present')
else:
    print('no a is not present')    

