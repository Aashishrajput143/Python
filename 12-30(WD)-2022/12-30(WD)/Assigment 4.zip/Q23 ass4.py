t=input('Enter the string:')
print(t[-1::-1])
