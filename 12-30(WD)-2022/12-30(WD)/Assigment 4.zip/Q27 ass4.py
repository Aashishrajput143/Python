s=input('enter string ')
c=input('enter character u want to find index')
if c in s:
    print(s.index(c))
else:
    print(s)
